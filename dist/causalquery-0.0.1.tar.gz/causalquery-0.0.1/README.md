# causalquery

Query a causal graph!

## install
pip install causalquery