# Copyright (c) 2025, Nick Gerend
# This file is part of the causalquery library
__version__ = "0.0.1"
from .graphquery import CausalQuery